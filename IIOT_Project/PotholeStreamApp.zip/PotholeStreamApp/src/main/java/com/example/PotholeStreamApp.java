package com.example;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.kafka.clients.admin.AdminClient;
import org.apache.kafka.clients.admin.NewTopic;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.common.errors.TopicExistsException;
import org.apache.kafka.common.serialization.Serde;
import org.apache.kafka.common.serialization.Serdes;
import org.apache.kafka.streams.KafkaStreams;
import org.apache.kafka.streams.StreamsBuilder;
import org.apache.kafka.streams.StreamsConfig;
import org.apache.kafka.streams.kstream.*;
import org.apache.kafka.streams.state.KeyValueStore;
import org.apache.kafka.streams.state.WindowStore;

import java.time.Duration;
import java.util.Arrays;
import java.util.Collections;
import java.util.Properties;
import java.util.Set;
import java.util.concurrent.ExecutionException;

public class PotholeStreamApp {

    private static final String RAW_EVENTS_TOPIC = "pothole-events";
    private static final String DEDUPLICATED_EVENTS_TOPIC = "deduplicated-pothole-events"; // Will contain PotholeState with severityCategory
    private static final String AGGREGATED_STATS_TOPIC = "aggregated-pothole-stats";
    private static final int AREA_PRECISION = 3; // For getAreaKey

    public static String getAreaKey(PotholeState state) {
        String formatString = "AREA_%." + AREA_PRECISION + "f_%." + AREA_PRECISION + "f";
        return String.format(formatString, state.getLatitude(), state.getLongitude());
    }

    public static void createTopics(Properties props) throws ExecutionException, InterruptedException {
        System.out.println(">>> PRE-CREATE_TOPICS: Checking and creating topics...");
        Properties adminProps = new Properties();
        adminProps.putAll(props);
        adminProps.remove(StreamsConfig.APPLICATION_ID_CONFIG);

        try (AdminClient adminClient = AdminClient.create(adminProps)) {
            Set<String> existingTopics = adminClient.listTopics().names().get();

            for (NewTopic topic : Arrays.asList(
                    new NewTopic(RAW_EVENTS_TOPIC, 1, (short) 1),
                    new NewTopic(DEDUPLICATED_EVENTS_TOPIC, 1, (short) 1),
                    new NewTopic(AGGREGATED_STATS_TOPIC, 1, (short) 1)
            )) {
                if (!existingTopics.contains(topic.name())) {
                    System.out.println(">>> PRE-CREATE_TOPICS: Creating topic: " + topic.name());
                    try {
                        adminClient.createTopics(Collections.singletonList(topic)).all().get();
                        System.out.println(">>> PRE-CREATE_TOPICS: Topic '" + topic.name() + "' created successfully.");
                    } catch (final InterruptedException | ExecutionException e) {
                        if (!(e.getCause() instanceof TopicExistsException)) throw e;
                        System.out.println(">>> PRE-CREATE_TOPICS: Topic '" + topic.name() + "' already exists (likely race or previous creation).");
                    }
                } else {
                    System.out.println(">>> PRE-CREATE_TOPICS: Topic '" + topic.name() + "' already exists.");
                }
            }
        }
        System.out.println(">>> PRE-CREATE_TOPICS: Topic pre-creation check complete.");
    }

    public static void main(String[] args) {
        Properties props = new Properties();
        // ***** USE A NEW APPLICATION ID FOR EACH TEST RUN WITH NEW LOGIC / CLEAN STATE *****
        props.put(StreamsConfig.APPLICATION_ID_CONFIG, "pothole-severity-category-v1"); // e.g., pothole-severity-category-v1
        props.put(StreamsConfig.BOOTSTRAP_SERVERS_CONFIG, "localhost:9092");
        props.put(StreamsConfig.DEFAULT_KEY_SERDE_CLASS_CONFIG, Serdes.String().getClass());
        props.put(StreamsConfig.DEFAULT_VALUE_SERDE_CLASS_CONFIG, Serdes.String().getClass());
        props.put(StreamsConfig.COMMIT_INTERVAL_MS_CONFIG, 1000);
        props.put(StreamsConfig.consumerPrefix(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG), "earliest");
        // props.put(StreamsConfig.CACHE_MAX_BYTES_BUFFERING_CONFIG, 0); // Can be removed

        try {
            createTopics(props);
        } catch (Exception e) {
            System.err.println(">>> FATAL_ERROR_PRE_CREATE: Could not create/verify topics, shutting down.");
            e.printStackTrace(System.err);
            System.exit(1);
        }

        final Serde<PotholeState> potholeStateSerde = new JsonPojoSerde<>(PotholeState.class);
        final Serde<AggregatedStats> aggregatedStatsSerde = new JsonPojoSerde<>(AggregatedStats.class);
        final Serde<RoadEvent> roadEventSerde = new JsonPojoSerde<>(RoadEvent.class);

        StreamsBuilder builder = new StreamsBuilder();
        final ObjectMapper objectMapper = new ObjectMapper();

        KStream<String, String> rawJsonInput = builder.stream(RAW_EVENTS_TOPIC);
        rawJsonInput.foreach((key, value) -> System.out.println(">>> RAW_JSON_CONSUMED: Key=[" + key + "], Value=[" + value + "]"));

        KStream<String, RoadEvent> roadEvents = rawJsonInput.flatMapValues(value -> {
            try {
                System.out.println(">>> PARSING_JSON: Attempting to parse: " + value);
                RoadEvent event = objectMapper.readValue(value, RoadEvent.class);
                if (event.getDeviceId() == null || event.getLocation() == null || event.getLocationId() == null || event.getEventType() == null) {
                    System.err.println(">>> PARSING_ERROR (flatMapValues): Skipping event with missing essential fields: " + value);
                    return Collections.emptyList();
                }
                if (!"pothole_detected".equals(event.getEventType())) {
                     System.out.println(">>> PARSING_FILTERED (flatMapValues): Skipping non-pothole event type: " + event.getEventType() + " in value: " + value);
                     return Collections.emptyList();
                }
                System.out.println(">>> PARSING_SUCCESS (flatMapValues): Parsed to RoadEvent: " + event.toString());
                return Collections.singletonList(event);
            } catch (Exception e) {
                System.err.println(">>> PARSING_EXCEPTION (flatMapValues): Failed to parse JSON to RoadEvent: " + value);
                e.printStackTrace(System.err);
                return Collections.emptyList();
            }
        });
        roadEvents.foreach((key, value) -> System.out.println(">>> ROAD_EVENT_STREAM (Post-Parse): Key=[" + key + "], RoadEventValue=[" + value.toString() + "]"));


        KGroupedStream<String, RoadEvent> groupedByLocation = roadEvents
            .groupBy(
                (key, roadEvent) -> roadEvent.getLocationId(),
                Grouped.with(Serdes.String(), roadEventSerde)
            );
        System.out.println(">>> TOPOLOGY: Defined groupBy location_id.");

        KTable<String, PotholeState> potholeStateTable = groupedByLocation.aggregate(
            () -> null, // Initializer
            (locationKey, newEvent, currentAggregate) -> { // Aggregator
                int numericSeverityFromEvent = newEvent.getSeverity(); // This is the int (1-5) from RoadEvent
                System.out.println(">>> KTABLE_AGGREGATING for locationKey: " + locationKey +
                                   ", newEvent numericSeverity: " + numericSeverityFromEvent);

                if (currentAggregate == null) {
                    PotholeState newState = new PotholeState(
                        locationKey,
                        newEvent.getTimestamp(),
                        newEvent.getTimestamp(),
                        numericSeverityFromEvent, // Pass numeric severity to constructor
                        1,
                        newEvent.getLatitudeFromLocation(),
                        newEvent.getLongitudeFromLocation()
                    );
                    System.out.println("    -> NEW. PotholeState created: " + newState.toString());
                    return newState;
                } else {
                    currentAggregate.setDetectionCount(currentAggregate.getDetectionCount() + 1);
                    currentAggregate.setLastReportedTimestampMs((long) (newEvent.getTimestamp() * 1000));
                    // PotholeState's setCurrentSeverityNumeric will handle updating the category
                    currentAggregate.setCurrentSeverityNumeric(Math.max(currentAggregate.getCurrentSeverityNumeric(), numericSeverityFromEvent));
                    System.out.println("    -> UPDATE. PotholeState updated: " + currentAggregate.toString());
                    return currentAggregate;
                }
            },
            Materialized.<String, PotholeState, KeyValueStore<org.apache.kafka.common.utils.Bytes, byte[]>>
                as("pothole-state-store-severity-cat-v1") // NEW STATE STORE NAME
                .withKeySerde(Serdes.String())
                .withValueSerde(potholeStateSerde)
        );
        System.out.println(">>> TOPOLOGY: Defined KTable aggregation for PotholeState.");

        KStream<String, PotholeState> updatedPotholeStatesStream = potholeStateTable.toStream();
        updatedPotholeStatesStream.to(DEDUPLICATED_EVENTS_TOPIC, Produced.with(Serdes.String(), potholeStateSerde));
        updatedPotholeStatesStream.print(Printed.<String, PotholeState>toSysOut().withLabel("DEDUPLICATED_OUTPUT_STREAM (to topic " + DEDUPLICATED_EVENTS_TOPIC + ")"));


        // --- WEEKLY STATS AGGREGATION ---
        // Consumes from DEDUPLICATED_EVENTS_TOPIC which now contains PotholeState with severityCategory
        KStream<String, PotholeState> sourceForWeeklyAggregation = builder.stream(
                DEDUPLICATED_EVENTS_TOPIC, Consumed.with(Serdes.String(), potholeStateSerde));

        sourceForWeeklyAggregation.foreach((key, value) -> System.out.println(">>> WEEKLY_AGG_INPUT_STREAM: Key=[" + key + "], Value=[" + value.toString() + "]"));

        KTable<Windowed<String>, AggregatedStats> weeklyAreaStats = sourceForWeeklyAggregation
            .groupBy(
                (potholeLocationKey, potholeStateValue) -> getAreaKey(potholeStateValue),
                Grouped.with(Serdes.String(), potholeStateSerde)
            )
            .windowedBy(TimeWindows.ofSizeWithNoGrace(Duration.ofDays(7)))
            .aggregate(
                () -> {
                    System.out.println(">>> WEEKLY_AGG_INITIALIZER_CALLED");
                    return new AggregatedStats();
                },
                (areaKey, newPotholeStateValue, currentAggregateStats) -> {
                    System.out.println(">>> WEEKLY_AGGREGATOR_CALLED: AreaKey=[" + areaKey +
                                       "], NewValueCurrentNumericSeverity=[" + newPotholeStateValue.getCurrentSeverityNumeric() +
                                       "], CurrentAggregateStats=[" + currentAggregateStats.toString() + "]");
                    if (currentAggregateStats.getAreaKey() == null) {
                        currentAggregateStats.setAreaKey(areaKey);
                    }
                    // This logic will count each PotholeState update message.
                    // For a count of *unique* potholes first seen in window, filter newPotholeStateValue.getDetectionCount() == 1
                    // and ensure its firstSeenTimestampMs is within the current window.
                    currentAggregateStats.setTotalPotholes(currentAggregateStats.getTotalPotholes() + 1);
                    currentAggregateStats.setSumSeverity(currentAggregateStats.getSumSeverity() + newPotholeStateValue.getCurrentSeverityNumeric());
                    currentAggregateStats.recalculateAvgSeverity();
                    System.out.println(">>> WEEKLY_AGGREGATOR_RESULT: Updated AggregateStats=[" + currentAggregateStats.toString() + "]");
                    return currentAggregateStats;
                },
                Materialized.<String, AggregatedStats, WindowStore<org.apache.kafka.common.utils.Bytes, byte[]>>
                    as("weekly-area-summary-store-cat-v1") // NEW STATE STORE NAME
                    .withKeySerde(Serdes.String()).withValueSerde(aggregatedStatsSerde)
            );
        System.out.println(">>> TOPOLOGY: Defined windowed aggregation logic (weeklyAreaStats).");

        weeklyAreaStats.toStream()
            .mapValues((windowedKey, aggregatedValue) -> {
                if (aggregatedValue != null) {
                    if (windowedKey.window() != null) {
                        aggregatedValue.setWindowStartMs(windowedKey.window().start());
                        aggregatedValue.setWindowEndMs(windowedKey.window().end());
                    }
                }
                System.out.println(">>> AGG_STATS_OUTPUT_STREAM: WindowedKey=[" + windowedKey.toString() +
                                   "], Value=[" + (aggregatedValue != null ? aggregatedValue.toString() : "null") + "]");
                return aggregatedValue;
            })
            .filter((key, value) -> value != null)
            .to(AGGREGATED_STATS_TOPIC, Produced.with(WindowedSerdes.timeWindowedSerdeFrom(String.class, Duration.ofDays(7).toMillis()), aggregatedStatsSerde));
        System.out.println(">>> TOPOLOGY: Defined .to(" + AGGREGATED_STATS_TOPIC + ")");


        // --- STARTUP AND SHUTDOWN ---
        final KafkaStreams streams = new KafkaStreams(builder.build(), props);
        Runtime.getRuntime().addShutdownHook(new Thread(() -> {
            System.out.println(">>> SHUTDOWN HOOK: Closing Kafka Streams...");
            streams.close(Duration.ofSeconds(30)); // Slightly longer timeout for stateful apps
            System.out.println(">>> SHUTDOWN HOOK: Kafka Streams closed.");
        }));

        try {
            System.out.println(">>> MAIN: Calling streams.cleanUp()...");
            streams.cleanUp();
            System.out.println(">>> MAIN: Calling streams.start()...");
            streams.start();
            System.out.println(">>> MAIN: Kafka Streams (with PotholeState categories) started successfully.");
            System.out.println(">>> MAIN: Application running. Press Ctrl+C to stop.");
            Thread.currentThread().join();
        } catch (final Throwable e) {
            System.err.println(">>> MAIN_ERROR: Application error during startup or runtime.");
            e.printStackTrace(System.err);
            System.exit(1);
        } finally {
            System.out.println(">>> MAIN: Main thread exiting.");
            if (streams.state() != KafkaStreams.State.NOT_RUNNING && streams.state() != KafkaStreams.State.ERROR) {
                streams.close(Duration.ofSeconds(10));
            }
        }
    }
}