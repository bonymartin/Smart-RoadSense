package com.example;

public class AggregatedStats {
    private String areaKey;
    private long windowStartMs;
    private long windowEndMs;
    private int totalPotholes;
    private int sumSeverity;
    private double avgSeverity;

    public AggregatedStats() {}

    public AggregatedStats(String areaKey, long windowStartMs, long windowEndMs, int totalPotholes, int sumSeverity) {
        this.areaKey = areaKey;
        this.windowStartMs = windowStartMs;
        this.windowEndMs = windowEndMs;
        this.totalPotholes = totalPotholes;
        this.sumSeverity = sumSeverity;
        this.avgSeverity = totalPotholes > 0 ? (double) sumSeverity / totalPotholes : 0.0;
    }

    // Getters
    public String getAreaKey() { return areaKey; }
    public long getWindowStartMs() { return windowStartMs; }
    public long getWindowEndMs() { return windowEndMs; }
    public int getTotalPotholes() { return totalPotholes; }
    public int getSumSeverity() { return sumSeverity; }
    public double getAvgSeverity() { return avgSeverity; }

    // Setters
    public void setAreaKey(String areaKey) { this.areaKey = areaKey; }
    public void setWindowStartMs(long windowStartMs) { this.windowStartMs = windowStartMs; }
    public void setWindowEndMs(long windowEndMs) { this.windowEndMs = windowEndMs; }
    public void setTotalPotholes(int totalPotholes) { this.totalPotholes = totalPotholes; }
    public void setSumSeverity(int sumSeverity) { this.sumSeverity = sumSeverity; }
    public void setAvgSeverity(double avgSeverity) { this.avgSeverity = avgSeverity; }


    public void recalculateAvgSeverity() {
        this.avgSeverity = this.totalPotholes > 0 ? (double) this.sumSeverity / this.totalPotholes : 0.0;
    }

    @Override
    public String toString() {
        return "AggregatedStats{" + "areaKey='" + areaKey + '\'' + ", windowStartMs=" + windowStartMs + ", windowEndMs=" + windowEndMs + ", totalPotholes=" + totalPotholes + ", avgSeverity=" + String.format("%.2f", avgSeverity) + '}';
    }
}