package com.example;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.time.Instant;
import java.time.OffsetDateTime;
import java.time.format.DateTimeFormatter;

@JsonIgnoreProperties(ignoreUnknown = true)
public class RoadEvent {

    @JsonProperty("event_type")
    private String eventType;

    private double timestamp;

    @JsonProperty("device_id")
    private String deviceId;

    @JsonProperty("location")
    private LocationObject location;

    @JsonProperty("accelerometer")
    private AccelerometerObject accelerometer;

    private int severity;

    @JsonProperty("location_id")
    private String locationId;

    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class LocationObject {
        private double lat;
        private double lon;
        public LocationObject() {}
        public double getLat() { return lat; }
        public void setLat(double lat) { this.lat = lat; }
        public double getLon() { return lon; }
        public void setLon(double lon) { this.lon = lon; }
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class AccelerometerObject {
        private double x;
        private double y;
        private double z;
        public AccelerometerObject() {}
        public double getX() { return x; }
        public void setX(double x) { this.x = x; }
        public double getY() { return y; }
        public void setY(double y) { this.y = y; }
        public double getZ() { return z; }
        public void setZ(double z) { this.z = z; }
    }

    public RoadEvent() {}

    public String getEventType() { return eventType; }
    public void setEventType(String eventType) { this.eventType = eventType; }

    @JsonProperty("timestamp")
    public void setTimestampIso(String isoTimestamp) {
        try {
            OffsetDateTime odt = OffsetDateTime.parse(isoTimestamp, DateTimeFormatter.ISO_OFFSET_DATE_TIME);
            this.timestamp = odt.toInstant().toEpochMilli() / 1000.0;
        } catch (Exception e) {
            System.err.println("Failed to parse timestamp ISO string: " + isoTimestamp + " - " + e.getMessage());
            this.timestamp = Instant.now().toEpochMilli() / 1000.0;
        }
    }
    public double getTimestamp() { return timestamp; }
    public void setTimestamp(double timestamp) { this.timestamp = timestamp; }

    public String getDeviceId() { return deviceId; }
    public void setDeviceId(String deviceId) { this.deviceId = deviceId; }

    public LocationObject getLocation() { return location; }
    public void setLocation(LocationObject location) { this.location = location; }

    public AccelerometerObject getAccelerometer() { return accelerometer; }
    public void setAccelerometer(AccelerometerObject accelerometer) { this.accelerometer = accelerometer; }

    @JsonProperty("severity")
    public void setSeverityFloat(double severityFloat) {
        if (severityFloat <= 0.2) this.severity = 1;
        else if (severityFloat <= 0.4) this.severity = 2;
        else if (severityFloat <= 0.6) this.severity = 3;
        else if (severityFloat <= 0.8) this.severity = 4;
        else this.severity = 5;
    }
    public int getSeverity() { return severity; }
    public void setSeverity(int severity) { this.severity = severity; }

    public String getLocationId() { return locationId; }
    public void setLocationId(String locationId) { this.locationId = locationId; }

    public double getLatitudeFromLocation() {
        return (this.location != null) ? this.location.getLat() : 0.0;
    }
    public double getLongitudeFromLocation() {
        return (this.location != null) ? this.location.getLon() : 0.0;
    }

    @Override
    public String toString() {
        return "RoadEvent{" + "eventType='" + eventType + '\'' + ", timestamp=" + timestamp + ", deviceId='" + deviceId + '\'' + ", locationLat=" + (location != null ? location.getLat() : "N/A") + ", locationLon=" + (location != null ? location.getLon() : "N/A") + ", severity=" + severity + ", locationId='" + locationId + '\'' + '}';
    }
}