package com.example;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import java.util.HashMap;
import java.util.Map;

@JsonIgnoreProperties(ignoreUnknown = true) // Good practice
public class PotholeState {
    private Map<String, String> tags;         // To hold InfluxDB tags like "locationKey"
    private long firstSeenTimestampMs;      // Timestamp of the first detection (milliseconds)
    private long lastReportedTimestampMs;   // Timestamp of the latest detection (milliseconds)
    private int currentSeverityNumeric;     // The numeric severity (e.g., 1-5)
    private String severityCategory;        // "LOW", "MEDIUM", "HIGH"
    private int detectionCount;
    private double latitude;
    private double longitude;

    // No-arg constructor for Jackson deserialization and KTable initialization
    public PotholeState() {
        this.tags = new HashMap<>();
    }

    // Main constructor
    public PotholeState(String locationKey,
                        double firstSeenTimestampSeconds, // Expecting seconds from RoadEvent
                        double lastReportedTimestampSeconds, // Expecting seconds from RoadEvent
                        int numericSeverity, // Numeric severity (1-5 from RoadEvent)
                        int detectionCount,
                        double latitude,
                        double longitude) {
        this(); // Call no-arg constructor to initialize tags map
        if (locationKey != null && !locationKey.isEmpty()) {
            this.tags.put("locationKey", locationKey);
        }
        this.firstSeenTimestampMs = (long) (firstSeenTimestampSeconds * 1000);
        this.lastReportedTimestampMs = (long) (lastReportedTimestampSeconds * 1000);
        this.detectionCount = detectionCount;
        this.latitude = latitude;
        this.longitude = longitude;
        // Set both numeric severity and derive the category
        setCurrentSeverityNumericAndUpdateCategory(numericSeverity);
    }

    // Helper method to map numeric severity (1-5) to a category string
    private String mapNumericSeverityToCategory(int numericSev) {
        // Define your mapping rules here. This is an example:
        // 1, 2 = LOW
        // 3     = MEDIUM
        // 4, 5 = HIGH
        if (numericSev <= 2) {
            return "LOW";
        } else if (numericSev == 3) {
            return "MEDIUM";
        } else if (numericSev >= 4) {
            return "HIGH";
        } else {
            return "UNKNOWN"; // Default for unexpected values
        }
    }

    // --- Getters ---
    public Map<String, String> getTags() { return tags; }
    public long getFirstSeenTimestampMs() { return firstSeenTimestampMs; }
    public long getLastReportedTimestampMs() { return lastReportedTimestampMs; }
    public int getCurrentSeverityNumeric() { return currentSeverityNumeric; }
    public String getSeverityCategory() { return severityCategory; }
    public int getDetectionCount() { return detectionCount; }
    public double getLatitude() { return latitude; }
    public double getLongitude() { return longitude; }

    // --- Setters ---
    public void setTags(Map<String, String> tags) { this.tags = tags; }
    public void setFirstSeenTimestampMs(long firstSeenTimestampMs) { this.firstSeenTimestampMs = firstSeenTimestampMs; }
    public void setLastReportedTimestampMs(long lastReportedTimestampMs) { this.lastReportedTimestampMs = lastReportedTimestampMs; }

    // Setter for numeric severity - also updates the string category
    public void setCurrentSeverityNumeric(int numericSeverity) {
        setCurrentSeverityNumericAndUpdateCategory(numericSeverity);
    }
    // Private helper to ensure both are updated together
    private void setCurrentSeverityNumericAndUpdateCategory(int numericSeverity) {
        this.currentSeverityNumeric = numericSeverity;
        this.severityCategory = mapNumericSeverityToCategory(numericSeverity);
    }
    // Direct setter for category might not be needed if always derived
    public void setSeverityCategory(String severityCategory) { this.severityCategory = severityCategory; }

    public void setDetectionCount(int detectionCount) { this.detectionCount = detectionCount; }
    public void setLatitude(double latitude) { this.latitude = latitude; }
    public void setLongitude(double longitude) { this.longitude = longitude; }

    // Convenience getter for locationKey from tags - ignored by Jackson during serialization
    @JsonIgnore
    public String getLocationKeyFromTags() {
        return (this.tags != null) ? this.tags.get("locationKey") : null;
    }

    @Override
    public String toString() {
        return "PotholeState{" +
               "tags=" + tags +
               ", firstSeenTimestampMs=" + firstSeenTimestampMs +
               ", lastReportedTimestampMs=" + lastReportedTimestampMs +
               ", currentSeverityNumeric=" + currentSeverityNumeric +
               ", severityCategory='" + severityCategory + '\'' +
               ", detectionCount=" + detectionCount +
               ", latitude=" + latitude +
               ", longitude=" + longitude +
               '}';
    }
}